package com.websparkbd.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.text.NumberFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Firebase initializes when google-services.json is added.
        try { FirebaseApp.initializeApp(this) } catch (_: Exception) { }
        setContent { WebsparkApp() }
    }
}

private enum class AppLanguage { EN, BN }
private enum class Screen(val key: String) {
    DASHBOARD("dashboard"), CLIENTS("clients"), PROJECTS("projects"),
    FINANCE("finance"), INVOICES("invoices"), TEAM("team"), REPORTS("reports")
}

@Composable
private fun WebsparkApp() {
    var language by remember { mutableStateOf(AppLanguage.EN) }
    var screen by remember { mutableStateOf(Screen.DASHBOARD) }
    var currency by remember { mutableStateOf("BDT") }
    var signedIn by remember { mutableStateOf(firebaseAuthOrNull()?.currentUser != null) }
    var showLogin by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF174A75),
            secondary = androidx.compose.ui.graphics.Color(0xFF168A82),
            background = androidx.compose.ui.graphics.Color(0xFFF5F7FA)
        )
    ) {
        if (!signedIn && showLogin) {
            AuthScreen(language, onBack = { showLogin = false }, onSignedIn = {
                signedIn = true
                showLogin = false
            })
        } else {
            Scaffold(
                topBar = {
                    TopAppBarCompat(
                        language = language,
                        currency = currency,
                        onLanguage = { language = if (language == AppLanguage.EN) AppLanguage.BN else AppLanguage.EN },
                        onCurrency = { currency = if (currency == "BDT") "USD" else "BDT" },
                        onLogin = { showLogin = true },
                        signedIn = signedIn
                    )
                },
                bottomBar = {
                    NavigationBar {
                        listOf(
                            Screen.DASHBOARD to label(language, "Home", "হোম"),
                            Screen.CLIENTS to label(language, "Clients", "ক্লায়েন্ট"),
                            Screen.PROJECTS to label(language, "Projects", "প্রজেক্ট"),
                            Screen.FINANCE to label(language, "Finance", "হিসাব")
                        ).forEach { (item, title) ->
                            NavigationBarItem(
                                selected = screen == item,
                                onClick = { screen = item },
                                icon = {
                                    Icon(
                                        when (item) {
                                            Screen.DASHBOARD -> Icons.Default.Dashboard
                                            Screen.CLIENTS -> Icons.Default.People
                                            Screen.PROJECTS -> Icons.Default.Folder
                                            else -> Icons.Default.AccountBalanceWallet
                                        }, contentDescription = title
                                    )
                                },
                                label = { Text(title) }
                            )
                        }
                    }
                }
            ) { padding ->
                Column(
                    modifier = Modifier.padding(padding).fillMaxSize()
                        .verticalScroll(rememberScrollState()).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    when (screen) {
                        Screen.DASHBOARD -> DashboardScreen(language, currency, onOpen = { screen = it })
                        Screen.CLIENTS -> FeatureScreen(language, "Clients", "ক্লায়েন্ট", "Client directory, contacts, status and history.")
                        Screen.PROJECTS -> FeatureScreen(language, "Projects & Tasks", "প্রজেক্ট ও টাস্ক", "Track milestones, deadlines, priorities and assignments.")
                        Screen.FINANCE -> FeatureScreen(language, "Income & Expense", "আয় ও ব্যয়", "Record transactions, categories, payment method and dates.")
                        Screen.INVOICES -> FeatureScreen(language, "Invoice PDF", "ইনভয়েস PDF", "Invoice workflow is planned; PDF generation is not wired in this starter.")
                        Screen.TEAM -> FeatureScreen(language, "Team Management", "টিম ম্যানেজমেন্ট", "Invite teammates and assign roles after backend setup.")
                        Screen.REPORTS -> FeatureScreen(language, "Reports", "রিপোর্ট", "Monthly cash flow and project reports will use Firestore data.")
                    }
                    if (!signedIn) {
                        AssistCard(
                            title = label(language, "Preview mode", "প্রিভিউ মোড"),
                            body = label(language,
                                "Screens are a UI starter. Sign in to connect Firebase data after setup.",
                                "এটি প্রাথমিক UI। Firebase সেটআপের পর লগইন করে ডেটা সংযুক্ত করুন।"),
                            button = label(language, "Login / Register", "লগইন / রেজিস্ট্রেশন"),
                            onClick = { showLogin = true }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TopAppBarCompat(
    language: AppLanguage, currency: String, onLanguage: () -> Unit,
    onCurrency: () -> Unit, onLogin: () -> Unit, signedIn: Boolean
) {
    Surface(shadowElevation = 2.dp, color = MaterialTheme.colorScheme.surface) {
        Row(
            modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.BusinessCenter, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text("Webspark BD", fontWeight = FontWeight.Bold)
                Text(label(language, "Business Management", "ব্যবসা ব্যবস্থাপনা"), style = MaterialTheme.typography.labelSmall)
            }
            TextButton(onClick = onCurrency) { Text(currency) }
            TextButton(onClick = onLanguage) { Text(if (language == AppLanguage.EN) "বাংলা" else "EN") }
            IconButton(onClick = onLogin) {
                Icon(if (signedIn) Icons.Default.AccountCircle else Icons.Default.Login, contentDescription = "Account")
            }
        }
    }
}

@Composable
private fun DashboardScreen(language: AppLanguage, currency: String, onOpen: (Screen) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Column {
            Text(label(language, "Business overview", "ব্যবসার সারসংক্ষেপ"), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(label(language, "A simple workspace for your business.", "আপনার ব্যবসার জন্য একটি সহজ কর্মক্ষেত্র।"), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard(label(language, "Clients", "ক্লায়েন্ট"), "—", Icons.Default.People, Modifier.weight(1f))
            MetricCard(label(language, "Active projects", "চলমান প্রজেক্ট"), "—", Icons.Default.Folder, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard(label(language, "Income", "আয়"), moneyPlaceholder(currency), Icons.Default.TrendingUp, Modifier.weight(1f))
            MetricCard(label(language, "Outstanding", "বকেয়া"), moneyPlaceholder(currency), Icons.Default.Schedule, Modifier.weight(1f))
        }
        Text(label(language, "Quick actions", "দ্রুত কাজ"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        listOf(
            Triple(label(language, "Invoices", "ইনভয়েস"), Icons.Default.ReceiptLong, Screen.INVOICES),
            Triple(label(language, "Team", "টিম"), Icons.Default.Groups, Screen.TEAM),
            Triple(label(language, "Reports", "রিপোর্ট"), Icons.Default.BarChart, Screen.REPORTS)
        ).forEach { (title, icon, target) ->
            ElevatedButton(onClick = { onOpen(target) }, modifier = Modifier.fillMaxWidth()) {
                Icon(icon, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(title)
            }
        }
        AssistCard(
            title = label(language, "Getting started", "শুরু করুন"),
            body = label(language,
                "Connect Firebase, create your first client and add a project.",
                "Firebase সংযুক্ত করুন, প্রথম ক্লায়েন্ট তৈরি করুন এবং একটি প্রজেক্ট যোগ করুন।"),
            button = label(language, "View clients", "ক্লায়েন্ট দেখুন"),
            onClick = { onOpen(Screen.CLIENTS) }
        )
    }
}

@Composable
private fun MetricCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier = modifier) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun FeatureScreen(language: AppLanguage, titleEn: String, titleBn: String, description: String) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(label(language, titleEn, titleBn), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(label(language, description, when (titleBn) {
            "ক্লায়েন্ট" -> "ক্লায়েন্টের তালিকা, যোগাযোগ, অবস্থা ও ইতিহাস।"
            "প্রজেক্ট ও টাস্ক" -> "মাইলস্টোন, ডেডলাইন, অগ্রাধিকার ও দায়িত্ব ট্র্যাক করুন।"
            "আয় ও ব্যয়" -> "লেনদেন, ক্যাটাগরি, পেমেন্ট পদ্ধতি ও তারিখ সংরক্ষণ করুন।"
            "ইনভয়েস PDF" -> "ইনভয়েস তৈরি ও PDF সুবিধা পরবর্তী ধাপে যুক্ত হবে।"
            "টিম ম্যানেজমেন্ট" -> "ব্যাকএন্ড সেটআপের পর সদস্য আমন্ত্রণ ও Role নির্ধারণ করুন।"
            else -> "মাসিক ক্যাশ ফ্লো ও প্রজেক্ট রিপোর্ট Firestore ডেটা থেকে তৈরি হবে।"
        }), color = MaterialTheme.colorScheme.onSurfaceVariant)
        AssistCard(
            title = label(language, "Module scaffold", "মডিউল কাঠামো"),
            body = label(language, "This screen is ready for feature implementation; no sample business records are fabricated.", "এই স্ক্রিনে পরবর্তী ধাপে ফিচার যুক্ত হবে; কোনো কাল্পনিক ব্যবসায়িক ডেটা দেখানো হচ্ছে না।"),
            button = label(language, "Back to dashboard", "ড্যাশবোর্ডে ফিরুন"),
            onClick = {}
        )
    }
}

@Composable
private fun AssistCard(title: String, body: String, button: String, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(body, style = MaterialTheme.typography.bodyMedium)
            TextButton(onClick = onClick) { Text(button) }
        }
    }
}

@Composable
private fun AuthScreen(language: AppLanguage, onBack: () -> Unit, onSignedIn: () -> Unit) {
    var isRegister by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val auth = firebaseAuthOrNull()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        TextButton(onClick = onBack) { Text(label(language, "← Back", "← ফিরে যান")) }
        Text("Webspark BD", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(label(language, if (isRegister) "Create an account" else "Sign in", if (isRegister) "অ্যাকাউন্ট তৈরি করুন" else "লগইন করুন"), style = MaterialTheme.typography.titleLarge)
        if (isRegister) OutlinedTextField(displayName, { displayName = it }, label = { Text(label(language, "Full name", "পূর্ণ নাম")) }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(email, { email = it.trim() }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(password, { password = it }, label = { Text(label(language, "Password (6+ characters)", "পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)")) }, modifier = Modifier.fillMaxWidth())
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(
            onClick = {
                error = null
                if (auth == null) {
                    error = label(language, "Firebase is not configured. Add app/google-services.json and set up Firebase first.", "Firebase সেটআপ করা হয়নি। আগে app/google-services.json যোগ করে Firebase সেটআপ করুন।")
                } else if (email.isBlank() || password.length < 6) {
                    error = label(language, "Enter a valid email and a password with at least 6 characters.", "সঠিক ইমেইল ও কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন।")
                } else {
                    busy = true
                    val task = if (isRegister) auth.createUserWithEmailAndPassword(email, password) else auth.signInWithEmailAndPassword(email, password)
                    task.addOnCompleteListener { result ->
                        busy = false
                        if (result.isSuccessful) {
                            if (isRegister && displayName.isNotBlank()) {
                                val profile = hashMapOf("displayName" to displayName, "email" to email, "createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp())
                                result.result?.user?.uid?.let { uid ->
                                    FirebaseFirestore.getInstance().collection("users").document(uid).set(profile)
                                }
                            }
                            onSignedIn()
                        } else {
                            error = result.exception?.localizedMessage ?: label(language, "Authentication failed.", "লগইন ব্যর্থ হয়েছে।")
                        }
                    }
                }
            },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
            else Text(label(language, if (isRegister) "Register" else "Login", if (isRegister) "রেজিস্ট্রেশন" else "লগইন"))
        }
        TextButton(onClick = { isRegister = !isRegister; error = null }) {
            Text(label(language, if (isRegister) "Already have an account? Login" else "New here? Create an account",
                if (isRegister) "আগে অ্যাকাউন্ট আছে? লগইন করুন" else "নতুন ব্যবহারকারী? অ্যাকাউন্ট তৈরি করুন"))
        }
        TextButton(onClick = {
            if (auth == null || email.isBlank()) {
                error = label(language, "Enter your email and configure Firebase.", "ইমেইল দিন এবং Firebase সেটআপ করুন।")
            } else {
                auth.sendPasswordResetEmail(email).addOnCompleteListener { result ->
                    error = if (result.isSuccessful) label(language, "Password reset email requested.", "পাসওয়ার্ড রিসেট ইমেইল পাঠানোর অনুরোধ হয়েছে।")
                    else result.exception?.localizedMessage ?: "Could not send reset email."
                }
            }
        }) { Text(label(language, "Forgot password?", "পাসওয়ার্ড ভুলে গেছেন?")) }
    }
}

private fun firebaseAuthOrNull(): FirebaseAuth? =
    try { FirebaseAuth.getInstance() } catch (_: Exception) { null }

private fun label(language: AppLanguage, en: String, bn: String): String =
    if (language == AppLanguage.BN) bn else en

private fun moneyPlaceholder(currency: String): String =
    if (currency == "BDT") "৳ —" else "$ —"
