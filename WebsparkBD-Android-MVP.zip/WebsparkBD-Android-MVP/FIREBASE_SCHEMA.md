# Firebase data model notes

All tenant-specific business data lives below `organizations/{orgId}/...`.
Membership document:
`organizations/{orgId}/members/{uid}`:
- `role`: owner | admin | finance | project_manager | team_member
- `status`: active | invited | disabled
- `joinedAt`: server timestamp

Recommended backend callable functions:
- `createOrganization(name, preferredCurrency, language)`
- `inviteMember(orgId, email, role)`
- `postTransaction(orgId, transactionInput, idempotencyKey)`
- `issueInvoice(orgId, invoiceInput)`
- `recordInvoicePayment(orgId, invoiceId, paymentInput)`
- `reverseTransaction(orgId, transactionId, reason)`
- `sendDueDateReminders()`

These functions must validate caller membership/role, validate all amounts and references,
write audit events, and use Firestore transactions or idempotency keys where needed.
Do not trust totals or role fields submitted by the Android client.
