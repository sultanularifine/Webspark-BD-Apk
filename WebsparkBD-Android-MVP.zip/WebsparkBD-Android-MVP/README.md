# Webspark BD Android MVP

Starter Android Studio project using Kotlin, Jetpack Compose, Firebase Authentication and Firestore dependencies.

## Included
- Dashboard UI scaffold
- Bottom navigation for Home, Clients, Projects, Finance
- Feature placeholder screens for Invoices, Team, Reports
- English/Bangla UI toggle
- BDT/USD display toggle
- Firebase Email/Password login, registration and password-reset UI
- Initial Firestore rules file

## Important status
This is a **starter project**, not a completed production business-management app.
- Dashboard figures are placeholders and no fake business records are generated.
- Client/project/finance screens are UI scaffolds; CRUD operations are not yet wired.
- Invoice PDF, push notifications, reports and team invitations still require implementation.
- Firebase auth requires a real Firebase project configuration.
- Organization creation and membership provisioning must be implemented with trusted Cloud Functions/Admin SDK.
- Review and test the rules before production use.

## Requirements
- Android Studio with JDK 17
- Android SDK Platform 35
- Internet connection for Gradle dependency resolution

## Firebase setup
1. Create a project in Firebase Console.
2. Add an Android app with package name `com.websparkbd.app`.
3. Download `google-services.json`.
4. Put it at `app/google-services.json` (same folder as `app/build.gradle.kts`).
5. In Firebase Authentication, enable Email/Password.
6. Create a Cloud Firestore database.
7. Publish the reviewed `firestore.rules` file.
8. Configure App Check before production.
9. Use Cloud Functions or a trusted admin process to create organizations and membership records.

## Build
1. Open the extracted `WebsparkBD-Android-MVP` folder in Android Studio.
2. Allow Gradle sync to complete.
3. For a UI-only preview build, you can skip Firebase config; auth actions will explain that Firebase is not configured.
4. For real Firebase authentication, add `app/google-services.json`, then sync Gradle again.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).

For command line, with Android SDK installed:
```bash
./gradlew assembleDebug
```
Windows:
```bat
gradlew.bat assembleDebug
```

## Suggested next implementation order
1. Auth state/navigation and organization onboarding.
2. Organization/member provisioning callable functions.
3. Client CRUD and Firestore indexes.
4. Project/task CRUD and assignment validation.
5. Transactions and invoice operations through trusted backend functions.
6. PDF generation and secure Firebase Storage paths.
7. FCM notifications and in-app notification center.
8. Reports, export, audit logging, emulator security tests.
9. Release signing, backup/recovery, privacy policy and production review.
